function addViaInput() {
  const container = document.getElementById("via-container");
  const currentCount = container.querySelectorAll("input").length;

  if (currentCount >= 5) {
    alert("経由地は最大5つまでです。");
    return;
  }

  const viaDiv = document.createElement("div");
  viaDiv.className = "via-input";
  viaDiv.innerHTML = `
    <input type="text" class="via" placeholder="経由地${currentCount + 1}">
    <button type="button" onclick="removeVia(this)">削除</button>
  `;
  container.appendChild(viaDiv);
}

function removeVia(button) {
  button.parentElement.remove();
}

function suggestEngine() {
  const dep = document.getElementById("departure").value.trim();
  const dest = document.getElementById("destination").value.trim();
  const budget = parseInt(document.getElementById("budget").value) || 0;
  const viaInputs = document.querySelectorAll(".via");
  const vias = Array.from(viaInputs).map(v => v.value.trim()).filter(v => v !== "");
  const checkboxes = document.querySelectorAll(".checkbox-group input:checked");
  const selectedTransports = Array.from(checkboxes).map(cb => cb.value);
  const concept = document.querySelector('input[name="concept"]:checked');
  const result = document.getElementById("result");
  const loader = document.getElementById("loader");
  const searchButton = document.querySelector('.search-button');

  // 初期化
  result.innerHTML = '';
  result.classList.remove('fade-in');
  loader.style.display = "block";
  searchButton.disabled = true;
  searchButton.textContent = "検索中…";

  // 入力枠色リセット
  document.getElementById("departure").style.borderColor = "";
  document.getElementById("destination").style.borderColor = "";

  // バリデーション
  if (!dep || !dest || selectedTransports.length === 0 || !concept) {
    if (!dep) document.getElementById("departure").style.borderColor = "red";
    if (!dest) document.getElementById("destination").style.borderColor = "red";
    loader.style.display = "none";
    searchButton.disabled = false;
    searchButton.textContent = "旅行エンジンを検索";
    result.innerHTML = `<p class="result-note" style="color:red">すべての項目を入力・選択してください。</p>`;
    return;
  }

  if (dep === dest) {
    loader.style.display = "none";
    searchButton.disabled = false;
    searchButton.textContent = "旅行エンジンを検索";
    result.innerHTML = `<p class="result-note" style="color:red">出発地と目的地は異なる場所を指定してください。</p>`;
    return;
  }

  // 選択された条件に応じたエンジン選択
  let suggestion = "";
  let engine = "";
  let budgetNote = "";
  let modifiedTransports = [...selectedTransports];

  if (budget > 0) {
    if (budget < 30000) {
      budgetNote = "低予算（1万円未満）のため、バスや在来線を優先することをお勧めします。";
      if (!modifiedTransports.includes("高速/路線バス") && !modifiedTransports.includes("在来線")) {
        modifiedTransports.push("高速/路線バス", "在来線");
      }
    } else if (budget < 100000) {
      budgetNote = "中程度の予算のため（1~7万円）のため、新幹線やバスのバランスよ差を重視。";
    } else {
      budgetNote = "高予算（7万円以上）のため、飛行機や新幹線を優先し、快適に。";
      if (!modifiedTransports.includes("飛行機") && !modifiedTransports.includes("新幹線")) {
        modifiedTransports.push("飛行機", "新幹線");
      }
    }
  }

  if (vias.length >= 4) {
    engine = "jorudan";
    suggestion = "経由地が4つ以上ある複雑な旅程には、ジョルダンが便利です。";
  } else {
    const transportSet = new Set(modifiedTransports);
    if (concept.value === "こだわり" || transportSet.has("在来線")) {
      engine = "jorudan";
      suggestion = "こだわり旅や在来線利用なら「ジョルダン」がおすすめです。";
    } else if (transportSet.has("飛行機")) {
      engine = "yahoo_jalmaas";
      suggestion = "飛行機を使うなら「Yahoo!路線」や「JAL MaaS」が便利です。";
    } else if (transportSet.has("高速/路線バス") || transportSet.has("自転車")) {
      engine = "navitime";
      suggestion = "バスや自転車の利用なら「NAVITIME」がおすすめです。";
    } else {
      engine = "yahoo";
      suggestion = "幅広く調べたいなら「Yahoo!路線」が無難です。";
    }
  }

  const buttons = {
    yahoo: `<a class="logo-button yahoo" href="https://transit.yahoo.co.jp/?from=${encodeURIComponent(dep)}&to=${encodeURIComponent(dest)}" target="_blank">Yahoo!路線</a>`,
    navitime: `<a class="logo-button navitime" href="https://www.navitime.co.jp/transfer/?start=${encodeURIComponent(dep)}&goal=${encodeURIComponent(dest)}" target="_blank">NAVITIME</a>`,
    jorudan: `<a class="logo-button jorudan" href="https://www.jorudan.co.jp/norikae/?from=${encodeURIComponent(dep)}&to=${encodeURIComponent(dest)}" target="_blank">ジョルダン</a>`,
    jalmaas: `<a class="logo-button jalmaas" href="https://www.jal.co.jp/jp/ja/relations/jalmaas/" target="_blank">JAL MaaS</a>`,
    airtrip: `<a class="logo-button airtrip" href="https://www.airtrip.jp/" target="_blank">エアトリ</a>`,
    skycanner: `<a class="logo-button skycanner" href="https://www.skyscanner.jp/" target="_blank">スカイキャナー</a>`,
  };

  // 出力生成
  let output = `<p><strong>${suggestion}</strong></p>`;
  if (budgetNote) {
    output += `<p class="result-note">${budgetNote}</p>`;
  }
  if (vias.length > 0) {
    output += `<p class="result-note">経由地: ${vias.join(" → ")}</p>`;
  }
  output += `<p class="result-note">選択した交通機関: ${selectedTransports.join(", ")}</p>`;
  output += `<p class="result-note">旅のコンセプト: ${concept.value}</p>`;

  if (engine === "yahoo_jalmaas") {
    output += buttons.yahoo + buttons.jalmaas;
    if (modifiedTransports.includes("飛行機")) {
      output += `
        <p class="result-note">✈️ 航空券を素早く安く予約したい方はこちら</p>
        ${buttons.airtrip}
        ${buttons.skycanner}
      `;
    }
  } else {
    output += buttons[engine];
  }

  output += `<p class="result-note">↑ボタンを押すとサイトに飛びます。早速旅行計画を始めよう！</p>`;

  // 0.4秒後に検索完了表示（フェイク読み込み演出）
  setTimeout(() => {
    loader.style.display = "none";
    result.innerHTML = `<div class="fade-in">${output}</div>`;
    searchButton.disabled = false;
    searchButton.textContent = "旅行エンジンを検索";
  }, 400);
}
